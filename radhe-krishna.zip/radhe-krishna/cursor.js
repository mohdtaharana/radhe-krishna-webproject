// cursor 
const cursor = document.querySelector('.custom-cursor');
let mouseX = 0; // Store mouse X position
let mouseY = 0; // Store mouse Y position
const speed = 0.2; // Speed of the cursor movement

// Move cursor on mouse move
document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX; // Update mouse X position
    mouseY = e.clientY; // Update mouse Y position
});

// Update cursor position smoothly
function animateCursor() {
    // Interpolating the cursor's position for a smoother effect
    const cursorX = parseFloat(cursor.style.left) || 0;
    const cursorY = parseFloat(cursor.style.top) || 0;

    // Smoothly move the cursor towards the mouse position
    const newCursorX = cursorX + (mouseX - cursorX) * speed;
    const newCursorY = cursorY + (mouseY - cursorY) * speed;

    cursor.style.left = `${newCursorX}px`;
    cursor.style.top = `${newCursorY}px`;

    requestAnimationFrame(animateCursor); // Call this function on the next animation frame
}

// Optional: Add a scaling effect on hover
document.addEventListener('mouseover', (e) => {
    if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') {
        cursor.style.transform = 'translate(-50%, -50%) scale(1.7)'; // Scale up
    } else {
        cursor.style.transform = 'translate(-50%, -50%)'; // Reset scale
    }
});

// Start the animation
animateCursor();